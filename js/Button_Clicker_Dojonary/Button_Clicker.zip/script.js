function logIn(element) {
    element.innerText = "Sign Out";
}

function remove(element) {
    element.remove();
}