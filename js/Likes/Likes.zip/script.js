// var count = 0;
// function addLike(element) {
//     count++;
//     console.log(count);
//     if (count == 1) {
//         document.getElementById("likeCounter1").innerHTML = `${count} Like`;
//     }
//     else {
//         document.getElementById("likeCounter1").innerHTML = `${count} Likes`;
//     }
// }

function addLike(element) {

    var a = Number(element.parentNode.children[0].innerHTML); // starts at zero
    var b = a + 1; // adds one
    element.parentNode.children[0].innerHTML = b;
    if (b == 0) {
        element.parentNode.children[1].innerHTML = "";
    }
    else if (b == 1) {
        element.parentNode.children[1].innerHTML = "Like";
    }
    else {
        element.parentNode.children[1].innerHTML = "Likes";
    }

    // element.parentNode.children[0].innerHTML = `${b} Likes`;
    // console.log(a);
    // console.log(b);
}

var loggedIn = false;
function logIn() {
    document.querySelector("h4").innerHTML = "Tyler Wertman";
    var loggedIn = true;
    console.log(loggedIn);
    return loggedIn;
}
console.log(loggedIn);
function addImage() {
    if (document.querySelector("h4").innerHTML == "Tyler Wertman") {
        document.getElementById("profilePic").src = "me.jpg";
    }
}
